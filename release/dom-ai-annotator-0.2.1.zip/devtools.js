import"./chunks/modulepreload-polyfill-B5Qt9EMX.js";chrome.devtools.panels.create("AI Debug","","src/devtools-panel/index.html");
