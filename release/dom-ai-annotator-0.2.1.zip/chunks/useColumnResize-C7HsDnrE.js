import{c as v,r as n}from"./x-D5ysmX6B.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=v("Pencil",[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]]),h=50;function E(c){const[u,a]=n.useState(c),s=n.useRef(null),i=n.useCallback((t,e)=>{e.preventDefault(),e.stopPropagation(),s.current={index:t,startX:e.clientX,startWidth:u[t]}},[u]);n.useEffect(()=>{function t(m){const o=s.current;if(!o)return;const d=m.clientX-o.startX,p=Math.max(h,o.startWidth+d);a(f=>{const r=[...f];return r[o.index]=p,r})}function e(){s.current=null}return document.addEventListener("mousemove",t),document.addEventListener("mouseup",e),()=>{document.removeEventListener("mousemove",t),document.removeEventListener("mouseup",e)}},[]);const l=n.useCallback(()=>s.current!==null,[]);return{widths:u,onResizeStart:i,isResizing:l}}export{z as P,E as u};
